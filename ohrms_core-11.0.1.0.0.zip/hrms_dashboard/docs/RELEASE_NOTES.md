## Module <hrms_dashboard>

#### 23.04.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project


#### 08.10.2018
#### Version 11.0.1.0.1
##### ADD
- Modified Dashboard with more details and graphs

#### 10.10.2018
#### Version 11.0.1.0.1
##### ADD
- Fix key Error 'month'

#### 25.10.2018
#### Version 11.0.2.0.0
##### UPDT
- Modify dashboard template view

#### 22.01.2019
#### Version 11.0.2.0.0
##### FIX
- Graph data issues (Birthday,Joining and resigning Trend and Attrition rate)
