## Module <ohrms_core>

#### 01.02.2019
#### Version 11.0.2.0.0
##### ADD
- Added Hrms link.

#### 25.04.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Open HRMS Core Module
