Open HRMS CORE v11
==================
* Open HRMS is a one-stop solution to manage human resource pool in a better and efficient format.
* It is a Open Source Project for empower Odoo HRMS by Cybrosys Technologies.
* Open HRMS is a set of modules, to empower Odoo HR module.
* Open HRMS CORE module is a suit that brings all the individual module into a single.
* It has selective - install approach for extra features.

Features
========
* Interactive Theme
* HR Dashboard
* HR Multi Company
* Biometric Device Automation
* Shift Management
* Loan Management
* Salary Advance
* Employee Reminders
* Employee Branch Transfer
* Advanced Employee Master
* Appraisal Plans & Strategies
* Employee Insurance
* HR Documents Management
* Entry & Exit Checklist
* Resignation Process
* HR Announcements
* Appreciations & Warnings
* Custody/Property Management
* Automation on Leaves Requests Mails
* Vacation Management
* Law Suit Management

Technical Notes
===============

Contacts
========
* Open HRMS <https://www.openhrms.com>
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Develoeprs
==========
* Developer: Nilmar Shereef @ cybrosys, shereef@cybrosys.in
* Developer: Jesni Banu @ cybrosys, jesni@cybrosys.in

