# -*- coding: utf-8 -*-
from . import hr_loan
from . import hr_payroll

